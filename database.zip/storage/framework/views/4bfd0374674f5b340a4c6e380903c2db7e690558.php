
<?php $__env->startSection('back_section'); ?>

    <!-- Page Wrapper -->
    <div id="wrapper">
    <?php echo $__env->make('includes.back_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
            <?php echo $__env->make('includes.back_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Begin Page Content -->
                <div class="container-fluid">
                    <?php if(session('message')): ?>
                        <div class="alert alert-<?php echo e(session('type')); ?> alert-dismissible fade show" role="alert">
                            <?php echo e(session('message')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php echo $__env->yieldContent('main_content'); ?>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-primary">Log out</button>
                    </form>
                </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    //count new mail
    countNewEmail();
    function countNewEmail() {
        $.ajax({
            url : "<?php echo e(route('contact.newmail')); ?>",
            method : 'GET',
            data : {},
            success : function (response) {
                $('#newMail').text(response.data);
            }
        });
    }

//    setInterval(function () {
//        countNewEmail();
//    },1000);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.back_primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xammp\htdocs\Laravel\Laravel_Portfolio\resources\views/layouts/back_master.blade.php ENDPATH**/ ?>