<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AboutText extends Model
{
    protected $fillable = ['top_text','bottom_text'];
}
