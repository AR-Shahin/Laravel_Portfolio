
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('main_content'); ?>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.back_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xammp\htdocs\Laravel\Laravel_Portfolio\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>