
<?php $__env->startSection('title','Projects'); ?>
<?php $__env->startSection('main_content'); ?>
    <style>
        body{
            background: rgba(248, 239, 186, 0.25);
        }
        .card{
            -webkit-transition: .6s;
            -moz-transition: .6s;
            -ms-transition: .6s;
            -o-transition: .6s;
            transition: .6s;
        }
        .card:hover{
            border:1px solid #c0392b;
        }
        img{
            -webkit-transition: .6s;
            -moz-transition: .6s;
            -ms-transition: .6s;
            -o-transition: .6s;
            transition: .6s;
        }
        .card:hover img{
            transform: scale(0.95);
        }
        .img_box ul {
            display: flex;
            margin-top:10px;
            justify-content: center;
        }
        .img_box ul li {
            height:40px;
            width:40px;
            margin: 0 8px;
            -webkit-border-radius:3px;
            -moz-border-radius:3px;
            border-radius:3px;
            transition: .6s;
        }
        .img_box ul li i{
            font-size: 20px;
            padding:9px;
            color: #fff;
        }
        .img_box ul li.youtube{
            background: #c0392b;
        }
        .img_box ul li.git{
            background: #09b83e;
        }
        .img_box ul li.eye{
            background: #0077B5;
        }
        .img_box ul li:hover{
            transform: scale(.9);
        }
    </style>
    <div class="container mt-5 pt-5">
        <div class="row text-center">
            <div class="col-12">
                <div class="sec_title wow animate__animated animate__zoomIn">
                    <h2 class="mb-0 pb-1">My Projects</h2>
                    <p class="m-0 p-0">What i will serve for you!</p>
                </div>
            </div>
        </div>
        <div class="row text-center my-4" id="projects">
            <div class="col-12">
                <div class="btn-group" role="group" aria-label="Second group">
                    <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-info <?php if($flag == '*'): ?> active <?php endif; ?>">All</a>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('category-wise-project',['slug' => $category->slug])); ?>" class="btn btn-info <?php if($flag == $category->slug): ?> active <?php endif; ?> "><?php echo e($category->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid mt-3">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-12 col-sm-6 col-md-3 mb-3">
                    <div class="project_box">
                        <div class="card">
                            <div class="card-body">
                                <div class="img_box text-center">
                                    <a href="<?php echo e(asset($project->thumb_image)); ?>" class="popup"><img src="<?php echo e(asset($project->image)); ?>" alt="<?php echo e($project->title); ?>" class="img-fluid" title="<?php echo e($project->title); ?>"></a>
                                    <div class="img-content">
                                        <h6 class="mt-3"><i style="color: #6D214F;font-size: 14px"><?php echo e($project->category->name); ?></i></h6>
                                        <h5><?php echo e($project->title); ?></h5>

                                        <ul>
                                            <a href="<?php echo e($project->youtube); ?>"><li class="youtube"><i class="fa fa-youtube"></i></li></a>
                                            <a href="<?php echo e($project->github); ?>"><li class="git"><i class="fa fa-github"></i></li></a>
                                            <a href="<?php echo e($project->live); ?>"><li class="eye"><i class="fa fa-eye"></i></li></a>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xammp\htdocs\Laravel\Laravel_Portfolio\resources\views/frontend/project/index.blade.php ENDPATH**/ ?>