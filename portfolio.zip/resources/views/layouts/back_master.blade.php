@extends('layouts.back_primary')
@section('back_section')

    <!-- Page Wrapper -->
    <div id="wrapper">
    @include('includes.back_sidebar')

    <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
            @include('includes.back_navbar')

            <!-- Begin Page Content -->
                <div class="container-fluid">
                    @if(session('message'))
                        <div class="alert alert-{{ session('type') }} alert-dismissible fade show" role="alert">
                            {{ session('message') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif
                    @yield('main_content')

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <form id="logout-form" action="{{ route('admin.logout') }}" method="POST" >
                        @csrf
                        <button class="btn btn-primary">Log out</button>
                    </form>
                </div>
            </div>
        </div>
    </div>




@stop

@push('script')
<script>
    //count new mail
    countNewEmail();
    function countNewEmail() {
        $.ajax({
            url : "{{route('contact.newmail')}}",
            method : 'GET',
            data : {},
            success : function (response) {
                $('#newMail').text(response.data);
            }
        });
    }

//    setInterval(function () {
//        countNewEmail();
//    },1000);
</script>
@endpush