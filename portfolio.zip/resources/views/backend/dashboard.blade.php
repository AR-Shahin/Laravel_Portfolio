@extends('layouts.back_master')
@section('title','Dashboard')
@section('main_content')
    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
@stop

